# Jennifer O. Eze
# BoldLink DevOps Engineer Phase One Test
# zipped copy of code can be found in https://github.com/jennifer-eze/BoldLink-Test 

print('Hello World')
greet = input()
print('Hello', greet)